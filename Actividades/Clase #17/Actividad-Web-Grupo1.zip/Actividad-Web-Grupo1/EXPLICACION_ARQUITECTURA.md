# Explicación de la arquitectura — para exponer en clase

## 1. ¿Por qué Arquitectura Hexagonal (Ports & Adapters)?

La idea central: **el núcleo de la aplicación (el "hexágono") no debe saber
nada del mundo exterior** — ni de `localStorage`, ni de `fetch`, ni del DOM.
El núcleo solo conoce **puertos** (interfaces/contratos). Todo lo que toca
el mundo real (navegador, red) es un **adaptador** que implementa esos puertos.

```
        ADAPTADOR PRIMARIO (entrada)
              ChatView (DOM)
                    │
                    ▼
   ┌─────────────────────────────────┐
   │      APLICACIÓN (casos de uso)   │
   │  LoadHistoryUseCase               │
   │  SendMessageUseCase                │
   │        │              │           │
   │   ChatRepositoryPort   ModelGatewayPort   ← PUERTOS
   └────────┼──────────────┼───────────┘
            │              │
            ▼              ▼
 LocalStorageChatRepository   JsonPlaceholderModelGateway
      (ADAPTADOR SECUNDARIO)      (ADAPTADOR SECUNDARIO)
```

**¿Qué ganamos?** Si mañana cambian `localStorage` por una base de datos, o
la API de prueba por un modelo real de IA, **solo se escribe un adaptador
nuevo**. Los casos de uso, el dominio y la UI no se tocan. Esto también hace
que el núcleo sea trivialmente testeable: en un test, se le puede inyectar
un `ChatRepositoryPort` falso en memoria, sin tocar el navegador.

## 2. ¿Dónde está el DDD (Domain-Driven Design)?

| Patrón DDD | En el proyecto | Por qué |
|---|---|---|
| **Value Object** | `Message` | Se define por su contenido (rol + texto), es inmutable, y se auto-valida en el constructor (no puede existir un mensaje con rol inválido o texto vacío). |
| **Entity / Aggregate Root** | `ChatHistory` | Es la única puerta de entrada para modificar la colección de mensajes. Nadie puede "meter la mano" al arreglo interno directamente — evita que se repita el bug original de guardar un estado corrupto a medias. |
| **Repository** | `ChatRepositoryPort` + `LocalStorageChatRepository` | El dominio pide "guarda este historial" sin saber cómo ni dónde se guarda realmente. |
| **Application Service (caso de uso)** | `SendMessageUseCase`, `LoadHistoryUseCase` | Orquestan el flujo de negocio (enviar un mensaje, cargar el historial) usando el dominio y los puertos, sin mezclar detalles técnicos. |

## 3. ¿Dónde está cada principio SOLID?

- **S — Single Responsibility (Responsabilidad Única):**
  Cada clase tiene una sola razón para cambiar. `Message` solo valida un
  mensaje. `ChatHistory` solo administra la colección. `ChatView` solo
  traduce DOM ↔ casos de uso. `LocalStorageChatRepository` solo sabe de
  `localStorage`.

- **O — Open/Closed (Abierto/Cerrado):**
  `ModelGatewayPort` permite agregar un nuevo proveedor de "modelo" (un
  backend real, un mock para pruebas) creando un adaptador nuevo, **sin
  modificar** `SendMessageUseCase`.

- **L — Liskov Substitution (Sustitución de Liskov):**
  Cualquier clase que implemente `ChatRepositoryPort` (por ejemplo, una
  futura `IndexedDbChatRepository`) puede reemplazar a
  `LocalStorageChatRepository` sin romper el caso de uso que la usa.

- **I — Interface Segregation (Segregación de Interfaces):**
  Los puertos son pequeños y específicos: `ChatRepositoryPort` solo tiene
  `load()`/`save()`; `ModelGatewayPort` solo tiene `getResponse()`. Nadie
  se ve obligado a implementar métodos que no necesita.

- **D — Dependency Inversion (Inversión de Dependencias):**
  `SendMessageUseCase` depende de las abstracciones (`ChatRepositoryPort`,
  `ModelGatewayPort`), nunca de las clases concretas. Las implementaciones
  reales se "inyectan" desde `main.js` (el *composition root*), el único
  archivo que conoce ambos mundos.

## 4. Conexión con los bugs originales de la Práctica 1

Esto es clave para la exposición: **la refactorización no es solo estética
— resuelve los bugs originales de raíz, a nivel de diseño:**

- **Memoria corrupta:** antes, el `JSON.stringify`/`JSON.parse` faltante
  era un detalle disperso en funciones sueltas. Ahora está encapsulado y
  aislado dentro de un único adaptador (`LocalStorageChatRepository`):
  si el bug volviera a aparecer, se sabe exactamente dónde buscar, y el
  resto del sistema (dominio, casos de uso, UI) ni se entera de cómo se
  serializa el historial.

- **Condición de carrera asíncrona:** antes, `enviar()` disparaba el fetch
  sin `await` y mostraba la respuesta con un `setTimeout` fijo adivinando
  el tiempo de red. Ahora, `SendMessageUseCase.execute()` encadena todo
  con `await` de forma secuencial: guardar mensaje del usuario → esperar
  respuesta real del modelo → guardar y devolver la respuesta. Es
  **arquitectónicamente imposible** que la UI reciba una respuesta antes
  de que el `fetch` haya terminado, porque ya no existe ningún
  temporizador arbitrario en el flujo.

## 5. Mejora agregada: botón "Modo offline" (demostración en vivo de OCP/DIP)

Se agregó un segundo adaptador, `FakeModelGateway`, que implementa el mismo
`ModelGatewayPort` que `JsonPlaceholderModelGateway`, pero sin tocar la red:
responde con textos simulados. Un tercer adaptador, `SwitchableModelGateway`,
se presenta ante `SendMessageUseCase` como si fuera un `ModelGatewayPort`
más, pero por dentro decide en tiempo real cuál de los dos usar según un
interruptor (`setOffline(true/false)`), controlado por el checkbox
"🔌 Modo offline" del header.

**Por qué es una mejora de bajo riesgo:** no se modificó ni una línea de
`SendMessageUseCase`, `ChatHistory`, `Message`, ni de la lógica ya
corregida de los 2 bugs originales. Solo se agregaron 2 archivos nuevos
(`FakeModelGateway.js`, `SwitchableModelGateway.js`) y se conectó el
checkbox en `ChatView`/`main.js`.

**Cómo demostrarlo en la exposición:** activa el checkbox y envía un
mensaje — la respuesta empieza con 🔌 y llega sin hacer ninguna petición
de red (se puede mostrar la pestaña Network vacía). Desactívalo y vuelve
a enviar — la respuesta llega vía `fetch` real. Esto demuestra en vivo
que el `SendMessageUseCase` nunca supo que el proveedor cambió: por eso
sirve tener un puerto (`ModelGatewayPort`) en vez de depender directamente
de `fetch`.

## 6. Cómo defenderlo si el profe pregunta "¿por qué tantas capas para algo tan simple?"

Respuesta honesta y válida: para un chat de un solo archivo, esta
arquitectura es "más grande" que el problema — y está bien decirlo. El
valor de mostrarla aquí es **demostrar que se entienden los patrones**
(puertos/adaptadores, entidades, inyección de dependencias) aplicándolos
a un caso pequeño y ya conocido, donde además se puede señalar
exactamente qué bug quedó resuelto en qué capa.
